# hello.py

def main():
    print("Hello world! This is version 1.0.1")
    print("Why did the my device go to therapy? It had too many unresolved dependencies.")

if __name__ == "__main__":
    main()
