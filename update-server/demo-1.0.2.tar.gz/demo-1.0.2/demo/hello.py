# hello.py

def main():
    print("Hello world! This is version 1.0.2")
    print("Why did the my device go to therapy? It had too many unresolved dependencies.")
    print("knock knock!")

if __name__ == "__main__":
    main()
