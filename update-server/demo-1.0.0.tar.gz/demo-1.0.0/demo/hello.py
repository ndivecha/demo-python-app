# hello.py

def main():
    print("Hello world! This is version 1.0.0")

if __name__ == "__main__":
    main()
